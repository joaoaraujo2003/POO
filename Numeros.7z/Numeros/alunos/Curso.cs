using global::System;
using global::System.Collections.Generic;
using global::System.IO;
using global::System.Linq;
using global::System.Net.Http;
using global::System.Threading;
using global::System.Threading.Tasks;
namespace alunos;
public class Curso
{
    public string Nome { get; set; }
    private List<Aluno> alunoMatriculados = new List<Aluno>();

    public Curso(string nome)
    {
        Nome = nome;
    }

    public void AdicionarAluno(Aluno aluno)
    {
        alunoMatriculados.Add(aluno);
    }

    public void ListarAlunos()
    {
        Console.WriteLine("Alunos matriculados no curso " + Nome + ":");
        foreach (var aluno in alunoMatriculados)
        {
            Console.WriteLine("Nome: {0}, Matricula: {1}", aluno.Nome, aluno.Matricula);
        }
    }
}
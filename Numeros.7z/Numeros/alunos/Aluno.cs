using global::System;
using global::System.Collections.Generic;
using global::System.IO;
using global::System.Linq;
using global::System.Net.Http;
using global::System.Threading;
using global::System.Threading.Tasks;
namespace alunos;
internal class Aluno
{
    public string Nome { get; set; }
    public int Matricula { get; set; }

    public Aluno(string nome, int matricula)
    {
        Nome = nome;
        Matricula = matricula;
    }
}
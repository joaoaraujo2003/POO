namespace Exercicio_2._1;

internal class Pessoa
{
    private string nome;
    private int idade;

    public Pessoa(string nome, int idade)
    {
        this.nome = nome;
        this.idade = idade;
    }

    public void MostrarNome()
    {
        Console.WriteLine("Nome: {0}", nome);
    }

    public void MostrarIdade()
    {
        Console.WriteLine("Idade: {0} anos", idade);
    }

    public void VerInfo()
    {
        MostrarIdade();
        MostrarNome();
    }
}